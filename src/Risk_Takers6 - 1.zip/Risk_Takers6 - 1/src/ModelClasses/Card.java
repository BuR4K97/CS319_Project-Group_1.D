package ModelClasses;

public class Card {

}
