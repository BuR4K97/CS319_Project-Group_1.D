package UIComponents;

import java.awt.Color;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

import AnimationComponents.AnimationHandler;
import Controller.GameController;
import HelperTools.ImageHandler;
import ModelClasses.Territory;
import RainMap.Pixel;

public class GamePanel extends DynamicPanel {
	
	private VisualTerritoryVisualization visualTerritoryPanel;
	private BufferedImage backgroundTexture;
	private ImageHandler imageBuffer;
	//Textual interface
	private JLabel phaseLabel;
	private JLabel playerLabel;
	//Interaction buttons
	private JButton nextPhaseButton;
	private JButton actionRequestButton;
	private JTextField actionAmountField;
	private boolean textualPanelUpdateRequest;
	
	private JButton attackTillCapture; 
	private JButton attackPerRoll;
	private JButton terminateAttack;
	
	public GamePanel()  {
		if(GameController.activeMode == null) return;
		setPreferredSize(new Dimension(1920, 1080));
		setBackground(Color.BLACK);
		setLayout(null);
		
		imageBuffer = new ImageHandler("maps\\OldMapTexture.jpeg");
		imageBuffer.constructData();
		backgroundTexture = imageBuffer.getBufferedData();
		
		visualTerritoryPanel = new VisualTerritoryVisualization();
		visualTerritoryPanel.initialize();
		
		phaseLabel = new JLabel();
		phaseLabel.setForeground(Color.WHITE);
		phaseLabel.setFont(new Font("Calibri", Font.BOLD, 32));
		phaseLabel.setBounds(595, 1013, 116, 29);
		add(phaseLabel);
		
		playerLabel = new JLabel();
		playerLabel.setFont(new Font("Calibri", Font.BOLD, 32));
		playerLabel.setBounds(715, 1013, 106, 29);
		add(playerLabel);
		
		/**************************************************************************************************************/
		nextPhaseButton = new JButton("Next Phase");
		nextPhaseButton.setBounds(815, 1013, 185, 29);
		nextPhaseButton.setBorderPainted(false);
		nextPhaseButton.setForeground(Color.GRAY);
		nextPhaseButton.setBackground(new Color(0, 0, 0, 0));
		nextPhaseButton.setFont(new Font("Calibri", Font.BOLD, 32));
		
		actionRequestButton = new JButton("Action Request");
		actionRequestButton.setBounds(985, 1013, 235, 29);
		actionRequestButton.setBorderPainted(false);
		actionRequestButton.setForeground(Color.GRAY);
		actionRequestButton.setBackground(new Color(0, 0, 0, 0));
		actionRequestButton.setFont(new Font("Calibri", Font.BOLD, 32));
		
		actionAmountField = new JTextField();
		actionAmountField.setBounds(1220, 1013, 40, 29);
		
		
		nextPhaseButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				GameController.interactions.requestNextPhase();
				AnimationHandler.terminateMouseOnTerritoryAnimation(visualTerritoryPanel.getFocusTerritories()[0]);
				AnimationHandler.terminateMouseOnTerritoryAnimation(visualTerritoryPanel.getFocusTerritories()[1]);
				visualTerritoryPanel.getFocusTerritories()[0] = null; visualTerritoryPanel.getFocusTerritories()[1] = null;
				textualPanelUpdateRequest = true;
			}
		});
		
		actionRequestButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					int actionAmount = Integer.parseInt(actionAmountField.getText());
					GameController.interactions.requestAction(actionAmount);
					AnimationHandler.terminateMouseOnTerritoryAnimation(visualTerritoryPanel.getFocusTerritories()[0]);
					AnimationHandler.terminateMouseOnTerritoryAnimation(visualTerritoryPanel.getFocusTerritories()[1]);
					visualTerritoryPanel.getFocusTerritories()[0] = null; visualTerritoryPanel.getFocusTerritories()[1] = null;
				}
				catch(NumberFormatException exception) {
					System.out.println("Enter an action amount!!!");
				}
			}
		});
		
		actionAmountField.setPreferredSize(new Dimension(90, 30));
		
		textualPanelUpdateRequest = true;
		
		add(nextPhaseButton);
		add(actionRequestButton);
		add(actionAmountField);
		/**************************************************************************************************************/
		
		
		
		attackTillCapture = new JButton("Attack Till Capture");
		attackTillCapture.setBounds(815, 1013, 285, 29);
		attackTillCapture.setBorderPainted(false);
		attackTillCapture.setForeground(Color.GRAY);
		attackTillCapture.setBackground(new Color(0, 0, 0, 0));
		attackTillCapture.setFont(new Font("Calibri", Font.BOLD, 32));
		
		attackPerRoll = new JButton("Attack Per Roll");
		attackPerRoll.setBounds(1090, 1013, 230, 29);
		attackPerRoll.setBorderPainted(false);
		attackPerRoll.setForeground(Color.GRAY);
		attackPerRoll.setBackground(new Color(0, 0, 0, 0));
		attackPerRoll.setFont(new Font("Calibri", Font.BOLD, 32));
		
		terminateAttack = new JButton("Terminate Attack");
		terminateAttack.setBounds(1305, 1013, 265, 29);
		terminateAttack.setBorderPainted(false);
		terminateAttack.setForeground(Color.GRAY);
		terminateAttack.setBackground(new Color(0, 0, 0, 0));
		terminateAttack.setFont(new Font("Calibri", Font.BOLD, 32));
		
		attackTillCapture.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				GameController.interactions.requestAttackTillCapture();
			}
			
		});
		attackPerRoll.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				GameController.interactions.requestAttackPerRoll();
			}
			
		});
		terminateAttack.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				GameController.interactions.terminateCombat();
			}
		
		});
		attackTillCapture.setVisible(false);
		attackTillCapture.setEnabled(false);
		attackPerRoll.setVisible(false);
		attackPerRoll.setEnabled(false);
		terminateAttack.setVisible(false);
		terminateAttack.setEnabled(false);
		
		visualTerritoryPanel.insertMouseListeners(this);
		add(attackTillCapture) ;
		add(attackPerRoll);
		add(terminateAttack);
	}
	
	
	public void initializeAttackScenario(Territory[] combatTerritories) {
		nextPhaseButton.setEnabled(false);
		nextPhaseButton.setVisible(false);
		actionRequestButton.setEnabled(false);
		actionRequestButton.setVisible(false);
		actionAmountField.setEnabled(false);
		actionAmountField.setVisible(false);
		attackTillCapture.setVisible(true);
		attackTillCapture.setEnabled(true);
		attackPerRoll.setVisible(true);
		attackPerRoll.setEnabled(true);
		terminateAttack.setVisible(true);
		terminateAttack.setEnabled(true);
		
		visualTerritoryPanel.inCombatMode(combatTerritories);
	}
	
	public void terminateAttackScenario() {
		nextPhaseButton.setEnabled(true);
		nextPhaseButton.setVisible(true);
		actionRequestButton.setEnabled(true);
		actionRequestButton.setVisible(true);
		actionAmountField.setEnabled(true);
		actionAmountField.setVisible(true);
		attackTillCapture.setVisible(false);
		attackTillCapture.setEnabled(false);
		attackPerRoll.setVisible(false);
		attackPerRoll.setEnabled(false);
		terminateAttack.setVisible(false);
		terminateAttack.setEnabled(false);
			
		visualTerritoryPanel.outCombatMode();
	}
	
	public void paintComponent(Graphics painter) {
		super.paintComponent(painter);
		//painter.drawImage(backgroundTexture, 0, 0, this);
		//ImageIcon icon = new ImageIcon("maps\\OldMapTexture.jpeg");
		//icon.paintIcon(this, painter, 0, 0);
		visualTerritoryPanel.paint(painter);
	}
	
	public void update() {
		visualTerritoryPanel.update();
		if(textualPanelUpdateRequest)
		{
			textualPanelUpdateRequest = false;
			playerLabel.setText(GameController.interactions.getActivePlayer().toString());
			Color playerColor = GameController.interactions.getActivePlayer().getColor();
			playerLabel.setForeground(new Color(playerColor.getRed(), playerColor.getGreen(), playerColor.getBlue(), 255));
			phaseLabel.setText(GameController.interactions.getActivePhase().toString());
		} 
	}
	
	public void destroy() {
		visualTerritoryPanel.destroy();
	}
	
}
