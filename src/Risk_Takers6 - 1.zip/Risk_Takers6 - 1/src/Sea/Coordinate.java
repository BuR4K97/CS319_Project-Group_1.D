package Sea;

public class Coordinate {
	public int y;
	public int x;
	public boolean move = false;
	public Coordinate(int x, int y) {
		this.x = x;
		this.y = y;
	}
}
