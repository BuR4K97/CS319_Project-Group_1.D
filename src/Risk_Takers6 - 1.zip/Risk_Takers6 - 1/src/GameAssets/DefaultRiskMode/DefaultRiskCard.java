package GameAssets.DefaultRiskMode;

import ModelClasses.Card;

public class DefaultRiskCard extends Card {

	
}
