package Controller;

public class Risk_Game {

	public static void main(String[] args) {
		
		MainApplication.initialize();
		//MainApplication.initializeGame();
		MainApplication.initializeMenu();
		
	}//main

}//endClass
